# plugin.video.blxdtvcatchup
A basic TV Catchup Add-on for Kodi.

- Author: blxd
- Version: 0.1.1
- Github: https://github.com/blxd/plugin.video.blxdtvcatchup

## Download and Installation

- Simply download [plugin.video.blxdtvcatchup-0.1.1.zip](https://github.com/blxd/plugin.video.blxdtvcatchup/releases/download/v0.1.1/plugin.video.blxdtvcatchup-0.1.1.zip) file and install it in Kodi.
- Or install my [repo add-on](https://github.com/blxd/repository.blxd.plugins) and then install the TV Catchup add-on from there.  
